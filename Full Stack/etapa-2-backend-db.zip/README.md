
# Etapa 2 - Integração com Banco de Dados (PostgreSQL)

## ✅ Objetivo
Conectar o backend da tela de login (Node.js + Express) com o banco de dados PostgreSQL usando variáveis de ambiente, configuração modular e validação de credenciais reais.

---

## 🧩 Estrutura Criada

```
login-api/
│
├── config/
│   └── db.js          # Conexão com o banco de dados
│
├── controllers/
│   └── authController.js   # Lógica de login
│
├── routes/
│   └── authRoutes.js       # Rota de login
│
├── .env               # Variáveis sensíveis
├── server.js          # Ponto principal da aplicação
├── package.json
```

---

## 🗃️ Banco de Dados - PostgreSQL

- Tabela criada: `users`
- Campos:
  - `id SERIAL PRIMARY KEY`
  - `email TEXT NOT NULL`
  - `password TEXT NOT NULL`

---

## 🔐 Arquivo .env
```env
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=login_db
DB_USER=postgres
DB_PASSWORD=rr20062003
```

---

## 🔌 Conexão com PostgreSQL

### 📁 config/db.js
```js
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_DATABASE,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

pool.connect()
  .then(() => console.log("✅ Conectado ao PostgreSQL com sucesso!"))
  .catch((err) => console.error("Erro ao conectar ao PostgreSQL:", err));

module.exports = pool;
```

---

## 🎯 Validação com banco

### 📁 controllers/authController.js
```js
const pool = require('../config/db');

const login = async (req, res) => {
  const { email, senha } = req.body;

  try {
    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1 AND password = $2',
      [email, senha]
    );

    if (result.rows.length > 0) {
      res.json({ mensagem: "Login válido" });
    } else {
      res.json({ mensagem: "Login inválido" });
    }
  } catch (error) {
    console.error("Erro na consulta:", error);
    res.status(500).json({ mensagem: "Erro interno no servidor" });
  }
};

module.exports = { login };
```

---

## 🌐 Rota

### 📁 routes/authRoutes.js
```js
const express = require('express');
const router = express.Router();
const { login } = require('../controllers/authController');

router.post('/login', login);

module.exports = router;
```

---

## 🚀 server.js atualizado
```js
const express = require('express');
const cors = require('cors');
require('dotenv').config();
require('./config/db');

const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

app.use('/', authRoutes);

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
```

---

## ✅ Teste com cURL

```bash
curl -X POST http://localhost:3001/login -H "Content-Type: application/json" -d "{"email":"admin@email.com", "senha":"123456"}"
```

Resposta esperada:
```json
{"mensagem":"Login válido"}
```
