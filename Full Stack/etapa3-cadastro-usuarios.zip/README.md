# Etapa 3 - Cadastro de Usuários (Back-end)

## 📁 Estrutura

```
login-api/
├── server.js
├── .env
├── config/
│   └── db.js
├── routes/
│   └── authRoutes.js
├── controllers/
│   └── authController.js
```

## 🧩 Funcionalidade adicionada
- Endpoint POST `/register`
- Verificação se o e-mail já está cadastrado
- Criptografia de senha com `bcrypt`
- Integração com PostgreSQL

## ✅ Teste no terminal
```bash
curl -X POST http://localhost:3001/register -H "Content-Type: application/json" -d "{"email":"novo@email.com", "password":"123456"}"
```
