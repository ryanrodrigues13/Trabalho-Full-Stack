const pool = require("../config/db");
const bcrypt = require("bcrypt");

const login = async (req, res) => {
  const { email, senha } = req.body;
  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    if (result.rows.length === 0) return res.status(401).json({ mensagem: "Login inválido" });

    const user = result.rows[0];
    const senhaValida = await bcrypt.compare(senha, user.password);
    if (!senhaValida) return res.status(401).json({ mensagem: "Login inválido" });

    res.json({ mensagem: "Login válido" });
  } catch (err) {
    res.status(500).json({ mensagem: "Erro no servidor", erro: err.message });
  }
};

const register = async (req, res) => {
  const { email, password } = req.body;
  try {
    const existe = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    if (existe.rows.length > 0) {
      return res.status(409).json({ mensagem: "E-mail já cadastrado" });
    }

    const senhaCriptografada = await bcrypt.hash(password, 10);
    await pool.query("INSERT INTO users (email, password) VALUES ($1, $2)", [email, senhaCriptografada]);

    res.status(201).json({ mensagem: "Usuário cadastrado com sucesso" });
  } catch (err) {
    res.status(500).json({ mensagem: "Erro no servidor", erro: err.message });
  }
};

module.exports = { login, register };
