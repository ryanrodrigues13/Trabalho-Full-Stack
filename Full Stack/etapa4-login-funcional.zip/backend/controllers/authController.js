const pool = require('../config/db');
const bcrypt = require('bcrypt');

const login = async (req, res) => {
  const { email, senha } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const usuario = result.rows[0];
    if (!usuario || !(await bcrypt.compare(senha, usuario.password))) {
      return res.status(401).json({ mensagem: 'Login inválido' });
    }
    res.status(200).json({ mensagem: 'Login válido' });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ mensagem: 'Erro interno do servidor' });
  }
};

const register = async (req, res) => {
  const { email, password } = req.body;
  try {
    const hash = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (email, password) VALUES ($1, $2)', [email, hash]);
    res.status(201).json({ mensagem: 'Usuário cadastrado com sucesso' });
  } catch (error) {
    console.error('Erro ao registrar usuário:', error);
    res.status(500).json({ mensagem: 'Erro interno ao registrar' });
  }
};

module.exports = { login, register };
