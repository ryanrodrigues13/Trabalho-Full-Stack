# Etapa 4 – Login funcional no Front-End

Nesta etapa, implementamos a conexão entre o formulário de login em React com o backend (Node.js + PostgreSQL). O objetivo foi permitir autenticação real, exibindo mensagens visuais de sucesso ou erro conforme as credenciais informadas.

---

## ✅ Funcionalidades Implementadas

- Conexão do formulário React com a API `/login`
- Validação de e-mail e senha usando bcrypt
- Mensagem de **sucesso (verde)** ou **erro (vermelha)** no front-end
- Layout original mantido e estilizado com React Icons
- Organização entre `frontend/` e `backend/` para separação de responsabilidades

---

## 📁 Estrutura de Pastas

```
etapa4-final/
├── backend/
│   ├── controllers/
│   │   └── authController.js
│   ├── routes/
│   │   └── authRoutes.js
│   └── server.js
├── frontend/
│   └── src/
│       ├── App.css
│       └── App.jsx
```

---

## 💻 Tecnologias Utilizadas

- React.js
- Node.js
- Express
- PostgreSQL
- Bcrypt
- Fetch API
- React Icons

---

## 🚀 Como testar

### Backend

1. Crie o arquivo `.env` com os dados do seu PostgreSQL:
   ```
   DB_HOST=localhost
   DB_PORT=5432
   DB_DATABASE=login_db
   DB_USER=postgres
   DB_PASSWORD=sua_senha
   ```

2. Execute o backend:
   ```bash
   node server.js
   ```

### Frontend

1. Instale as dependências:
   ```bash
   npm install react-icons
   ```

2. Rode o projeto React:
   ```bash
   npm run dev
   ```

---

## 🧪 Testes

- Caso o login seja bem-sucedido, aparece: ✅ `Login válido` (verde)
- Se for inválido, aparece: ❌ `Login inválido` (vermelho)

---

## 🔒 Pronto para o próximo passo?

A próxima etapa (Etapa 5) adiciona autenticação JWT, com proteção de rotas e sessão persistente.

