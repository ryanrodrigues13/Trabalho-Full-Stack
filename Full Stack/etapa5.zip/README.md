# Etapa 5 – Autenticação com JWT (Token)

Nesta etapa, você integrou o uso de tokens JWT para proteger rotas no seu back-end.

---

## 📌 Passos realizados

### 1. Instalação de dependências

```bash
npm install jsonwebtoken dotenv
```

---

### 2. Atualização do .env

Incluído o segredo do JWT:

```env
JWT_SECRET=minh4Ch4veJWTsegur4
```

---

### 3. Geração de token no login

Atualizado `authController.js` para gerar e retornar um token ao usuário após login válido.

---

### 4. Rota protegida

Adicionado endpoint `/protegido` que só pode ser acessado com token válido.

---

### 5. Testes

Autenticação testada via `curl` no terminal:

```bash
curl -X POST http://localhost:3001/login -H "Content-Type: application/json" -d "{"email":"seu@email.com", "senha":"suasenha"}"
```

Utilizando o token retornado:

```bash
curl -X GET http://localhost:3001/protegido -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

---