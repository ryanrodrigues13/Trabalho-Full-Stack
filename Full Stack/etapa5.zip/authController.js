const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

require('dotenv').config();

exports.login = async (req, res) => {
    const { email, senha } = req.body;

    try {
        const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];

        if (user && await bcrypt.compare(senha, user.password)) {
            const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.json({ mensagem: "Login válido", token });
        } else {
            res.status(401).json({ mensagem: "Login inválido" });
        }
    } catch (err) {
        res.status(500).json({ mensagem: "Erro no servidor" });
    }
};

exports.register = async (req, res) => {
    const { email, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.query('INSERT INTO users (email, password) VALUES ($1, $2)', [email, hashedPassword]);
        res.json({ mensagem: 'Usuário cadastrado com sucesso' });
    } catch (err) {
        res.status(500).json({ mensagem: 'Erro ao registrar usuário' });
    }
};

exports.protegido = (req, res) => {
    res.json({ mensagem: "Acesso autorizado!", usuario: req.usuario });
};