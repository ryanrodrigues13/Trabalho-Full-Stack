exports.login = (req, res) => {
  const { email, senha } = req.body;

  if (email === 'teste@email.com' && senha === '123456') {
    res.status(200).json({ mensagem: 'Login realizado com sucesso' });
  } else {
    res.status(401).json({ mensagem: 'Login inválido' });
  }
};