# Backend Login API (Etapa 1 - Full Stack do Zero)

## 🧾 Descrição
API básica feita com Node.js e Express para receber requisições de login.

## 📁 Estrutura
- `server.js`: inicializa o servidor e define o roteamento principal
- `routes/authRoutes.js`: define o endpoint POST `/login`
- `controllers/authController.js`: lógica para validar login com dados fixos

## ▶️ Como Rodar
```bash
cd login-api
npm install
node server.js
```

Acesse via:
```bash
curl -X POST http://localhost:3001/login -H "Content-Type: application/json" -d "{\"email\":\"teste@email.com\", \"senha\":\"123456\"}"
```

## ✅ Resultado Esperado
```json
{
  "mensagem": "Login realizado com sucesso"
}
```
Ou:
```json
{
  "mensagem": "Login inválido"
}
```